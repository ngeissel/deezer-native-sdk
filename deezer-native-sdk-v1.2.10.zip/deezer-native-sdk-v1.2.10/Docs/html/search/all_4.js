var searchData=
[
  ['format',['format',['../structdz__media__track__detailed__infos__t.html#a3d0538e82f7bfa57e7cfd0a421bbeb18',1,'dz_media_track_detailed_infos_t::format()'],['../structdz__media__track__detailed__infos__t.html#a393627af3ab7492a0c6352fe329b1dc9',1,'dz_media_track_detailed_infos_t::format()']]]
];
