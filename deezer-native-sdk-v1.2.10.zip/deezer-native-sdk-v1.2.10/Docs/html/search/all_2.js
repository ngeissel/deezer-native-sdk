var searchData=
[
  ['channel_5fposition_5fmask',['channel_position_mask',['../structdz__media__track__detailed__infos__t.html#a7a674f2bfa78ac41827af651b85d41e0',1,'dz_media_track_detailed_infos_t']]],
  ['channels',['channels',['../structdz__media__track__detailed__infos__t.html#affe05b3e16ee350f606736653710aa42',1,'dz_media_track_detailed_infos_t']]],
  ['connect_5fevent_5fcb',['connect_event_cb',['../structdz__connect__configuration.html#ac93eda83a6d1a6d2439b30c8659ce3cc',1,'dz_connect_configuration']]]
];
