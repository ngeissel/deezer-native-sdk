var searchData=
[
  ['deezer_20localstorage_20model',['Deezer Localstorage model',['../_deezer_localstorage_model.html',1,'']]]
];
