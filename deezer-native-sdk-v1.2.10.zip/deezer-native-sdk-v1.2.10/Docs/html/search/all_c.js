var searchData=
[
  ['welcome_20to_20the_20deezer_20native_20sdk_20api_20manual_2e',['Welcome to the DEEZER Native SDK API manual.',['../index.html',1,'']]]
];
