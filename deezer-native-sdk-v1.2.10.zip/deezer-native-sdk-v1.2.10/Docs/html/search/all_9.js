var searchData=
[
  ['total_5fsamples',['total_samples',['../structdz__media__track__detailed__infos__t.html#afae5ba424cdebfb37e382e1b859e4aa2',1,'dz_media_track_detailed_infos_t']]]
];
