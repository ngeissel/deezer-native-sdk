var searchData=
[
  ['deezer_20connect_20c_20api',['Deezer Connect C API',['../group___deezer_c_api_connect.html',1,'']]],
  ['deezer_20mediatrack_20c_20api',['Deezer MediaTrack C API',['../group___deezer_c_api_media_track.html',1,'']]],
  ['deezer_20offline_20c_20api',['Deezer Offline C API',['../group___deezer_c_api_offline_api.html',1,'']]],
  ['deezer_20offline_20c_20synchronous_20api',['Deezer Offline C synchronous API',['../group___deezer_c_api_offline_sync_api.html',1,'']]],
  ['deezer_20player_20c_20api',['Deezer Player C API',['../group___deezer_c_api_player.html',1,'']]],
  ['deezer_20rest_20c_20api',['Deezer REST C API',['../group___deezer_c_api_rest_api.html',1,'']]]
];
